﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 测试
{
    public partial class Form1 : Form
    {
        int i = 0,j=0,size=20;
        Random r;
        Label[] Labelsum;
        Label labelfood;
   
        public Form1()
        {
            Labelsum = new Label[20];
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Labelsum[j].Top = 100;
            //Labelsum[j].Left += size;
            //j++;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            labelfood = new Label() {
            BackColor=Color.Red};
            labelfood.Width = labelfood.Height = 20;
            labelfood.BackColor = Color.Red;
            labelfood.Location = new Point(r.Next(this.Width), r.Next(this.Height));
            Labelsum[i] = labelfood;
            i++;
            this.Controls.Add(labelfood);
           
        }
    }
}
